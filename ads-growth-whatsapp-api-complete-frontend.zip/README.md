# ADS GROWTH WHATSAPP API — Website starter

## Upload to GitHub Pages (Android)
1. Download and extract this ZIP on your phone.
2. Open your GitHub repository → Add file → Upload files.
3. Upload the files inside the extracted folder (index.html, style.css, script.js, README.md), not the ZIP itself.
4. Tap Commit changes.
5. Open repository Settings → Pages.
6. Choose Deploy from a branch, branch `main`, folder `/ (root)`, then Save.

## Important: frontend demo only
This package is an attractive static website starter. It is NOT a functioning payment, admin, customer-account, API-key or WhatsApp backend.
Payment methods displayed are options to configure, not live payment rails. Before accepting money:
- Configure verified business UPI QR/UPI ID and bank details.
- For cards/netbanking/UPI gateway, open a merchant account with a payment provider and implement server-side order creation, signed webhook verification, refunds/reconciliation.
- Build secure backend authentication and role-based admin permissions; do not rely on a hidden frontend admin page.
- Payment screenshots/UTR must not auto-approve payments. Reconcile transactions against bank/provider records.
- Implement secure database, file storage, audit logs and per-customer API key handling.
- Meta WhatsApp Cloud API requires an eligible Meta Business setup, approved phone number/templates as applicable, and private server-side credentials. Never commit tokens or passwords to GitHub.
- Replace `REPLACE_WITH_SUPPORT_EMAIL` in `script.js` with your business support email.
- Replace all sample copy and contact information with truthful business details.
